


public class TestFinally{
    
 

    public static void main(String[] args) {
     
            System.out.println("entrer votre code ");
            // traiter cette exception 
          int x =   System.in.read();

     

        // afficher toujours le message "Merci de votre visite"
     
    }

}


